const jwt = require("jsonwebtoken");
const userDetails = require("../models/userDetails");

const Auth = async (req, res, next) => {
  try {
    const token = req.cookies.user;
    const verifyUser = jwt.verify(token, process.env.SECRET_JWT_KEY);
    const user = await userDetails.findOne({ _id: verifyUser._id });

    req.token = token;
    req.user = user;

    next();
  } catch (error) {
    res.status(404).redirect("/signin");
    // res.status(404).send(error);
  }
};

module.exports = Auth;
