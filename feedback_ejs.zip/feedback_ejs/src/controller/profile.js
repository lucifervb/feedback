const userDetails = require("../models/userDetails");
const jwt = require("jsonwebtoken");

// PROFILE
exports.profile = (req, res) => {
  userDetails.find({}, async function (error, userdetails) {
    try {
      const token = req.cookies.user;
      const userData = req.user;
      const name = userData.name;
      const email = userData.email;
      const devicecode = userData.devicecode;
      const verifyUser = jwt.verify(token, process.env.SECRET_JWT_KEY);
      const user = await userDetails.findOne({ _id: verifyUser._id });

      req.token = token;
      req.user = user;

      res.render("profile.ejs", {
        name: name,
        email: email,
        devicecode: devicecode,
        title: "Profile",
      });
    } catch (error) {
      console.log(error);
    }
  });
};
