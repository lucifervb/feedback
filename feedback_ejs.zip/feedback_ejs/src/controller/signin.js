const bcrypt = require("bcryptjs");
const userDetails = require("../models/userDetails");
const jwt = require("jsonwebtoken");

// SIGNIN
exports.signin = (req, res) => {
  res.render("signin.ejs", { title: "signin" });
};

// USEING SIGNIN FOR LOGIN
exports.authsignin = async (req, res) => {
  try {
    const email = req.body.email;
    const password = req.body.password;
    const useremail = await userDetails.findOne({ email: email });
    const checkpassword = await bcrypt.compare(password, useremail.password);
    
    const token = await useremail.genrateAuthToken();
    res.cookie("user", token, {
      expires: new Date(Date.now() + 1800000),
      httpOnly: true,
      // secure: true
    });

    // Normal Check if (password === useremail.password)

    // bcrypt check if (checkpassword)

    if (checkpassword) {
      res.status(201).redirect("/feedback");
    } else {
      res.redirect("/signin");
    }
  } catch (error) {
    res.status(400).send("INVALID CREDENTIALS");
  }
};
