const userDetails = require("../models/userDetails");
const jwt = require("jsonwebtoken");

// ABOUTVP
exports.aboutvp = (req, res) => {
  userDetails.find({}, async function (error, userdetails) {
    try {
      const token = req.cookies.user;
      const userData = req.user;
      const name = userData.name;
      const email = userData.email;
      const devicecode = userData.devicecode;
      const verifyUser = jwt.verify(token, process.env.SECRET_JWT_KEY);
      const user = await userDetails.findOne({ _id: verifyUser._id });

      req.token = token;
      req.user = user;

      let mqttData = userData.datas;

    //   let verygoodData = mqttData.filter((mqttData) => mqttData.data == 5);
    //   let goodData = mqttData.filter((mqttData) => mqttData.data == 4);
    //   let averageData = mqttData.filter((mqttData) => mqttData.data == 3);
    //   let badData = mqttData.filter((mqttData) => mqttData.data == 2);
    //   let verybadData = mqttData.filter((mqttData) => mqttData.data == 1);

      res.render("aboutvp.ejs", {
        name: name,
        email: email,
        devicecode: devicecode,
        title: "AboutUs",
      });
    } catch (error) {
      console.log(error);
    }
  });
};
