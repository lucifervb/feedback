const bcrypt = require("bcryptjs");
const userDetails = require("../models/userDetails");
const jwt = require("jsonwebtoken");

// SIGNUP
exports.signup = (req, res) => {
  res.render("signup.ejs", { title: "signup" });
};

// USEING SIGNUP FOR CREATING DATABASE
exports.authsignup = async (req, res) => {
  try {
    const password = req.body.password;
    const repassword = req.body.repassword;
    
    if (password === repassword) {
      
      const registerClient = new userDetails({
        name: req.body.name,
        email: req.body.email,
        devicecode: req.body.devicecode,
        password: password,
        confirmpassword: repassword,
      });

      const token = await registerClient.genrateAuthToken();
      res.cookie("user", token, {
        expires: new Date(Date.now() + 300000),
        httpOnly: true,
        // secure: true
      });

      const userRegisterd = await registerClient.save();

      res.status(201).redirect("/signin");
    } else res.send("INVALID CREDENTIALS");
  } catch (error) {
    res.status(400).send(error);
  }
};
