// INDEX
exports.index = (req,res) => {
    res.render('index.ejs', {title: 'feedback'});
}
