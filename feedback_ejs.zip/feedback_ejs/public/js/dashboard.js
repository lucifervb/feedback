let menuBtn = document.getElementById("btn");
let sidebar = document.getElementById("sidebar");

menuBtn.onclick = function () {
  sidebar.classList.toggle("active");
};