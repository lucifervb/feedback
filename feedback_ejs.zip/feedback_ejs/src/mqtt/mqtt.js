const mqtt = require("mqtt");
const userDetails = require("../models/userDetails");

//IF MQTT SERVER IS OPEN  HOST / APT (address)
//broker.hivemq.com
//3.87.196.177:1883
const Client = mqtt.connect("mqtt://broker.feelfeedback.in"); // Replace the host address with your given address protocall should be ins (mqtt:// or ws://)

//IF MQTT SERVER IS PASSWORD PROTECTED
// var client = mqtt.connect("ws://IP ADDRESS:PORT", {   // Replace the host address with your given address protocall should be ins (mqtt:// or ws://)s
//     username: "username",  // your broker username
//     password: "password",   // your broker password
// });

const filename = "mqtt.txt";

Client.on("connect", () => {
  Client.subscribe("mqttfeelfeedback");
  console.log("MQTT Started on Address broker.feelfeedback.in");
});

Client.on("message", async function (topic, payload) {
  try {
    const mqttdeviceid = payload.toString().slice(0, 15);
    const mqttdevicedata = payload.toString().charAt(16);
    const userdevicecode = await userDetails.findOne({
      devicecode: mqttdeviceid,
    });
    if (mqttdeviceid == userdevicecode.devicecode) {
      const updatedata = await userDetails.findOneAndUpdate(
        { _id: userdevicecode._id },
        {
          $push: {
            datas: { data: mqttdevicedata },
          },
        }
      );
    } else {
      console.log("fail");
    }
  } catch (error) {
    console.log("Device does not exist");
  }
});

module.exports = Client;
