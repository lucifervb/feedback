const userDetails = require("../models/userDetails");
const jwt = require("jsonwebtoken");

// TABLE
exports.table = (req, res) => {
  userDetails.find({}, async function (error, userdetails) {
    try {
      const token = req.cookies.user;
      const userData = req.user;
      const name = userData.name;
      const email = userData.email;
      const verifyUser = jwt.verify(token, process.env.SECRET_JWT_KEY);
      const user = await userDetails.findOne({ _id: verifyUser._id });

      req.token = token;
      req.user = user;

      let mqttData = userData.datas;

      let verygoodData = mqttData.filter((mqttData) => mqttData.data == 5);
      let goodData = mqttData.filter((mqttData) => mqttData.data == 4);
      let averageData = mqttData.filter((mqttData) => mqttData.data == 3);
      let badData = mqttData.filter((mqttData) => mqttData.data == 2);
      let verybadData = mqttData.filter((mqttData) => mqttData.data == 1);

      let vgData = verygoodData.length.toString();

      let gData = goodData.length.toString();

      let aData = averageData.length.toString();

      let bData = badData.length.toString();

      let vbData = verybadData.length.toString();


      // let vgData = verygoodData.length.toString();
      // let vggData = verygoodData.length;

      // let gData = goodData.length.toString();
      // let ggData = goodData.length;

      // let aData = averageData.length.toString();
      // let aaData = averageData.length;

      // let bData = badData.length.toString();
      // let bbData = badData.length;

      // let vbData = verybadData.length.toString();
      // let vbbData = verybadData.length;

      // let agData = parseInt((vggData + ggData) / 2);

      // let abData = parseInt((bbData + vbbData) / 2);

      // let Max = vggData + ggData + aaData + bbData + vbbData;

      // let avData = parseInt(Max / 5);

      res.render("table.ejs", {
        name: name,
        email: email,
        title: "Table",
        verygood: vgData,
        good: gData,
        average: aData,
        bad: bData,
        verybad: vbData,
        // averagegood: agData,
        // average: avData,
        // max: Max,
        // averagebad: abData,
      });
    } catch (error) {
      console.log(error);
    }
  });
};
