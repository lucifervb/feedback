const bcrypt = require("bcryptjs");
const userDetails = require("../models/userDetails");
const jwt = require("jsonwebtoken");

// SIGNOUT
exports.signout = async (req, res) => {
  try {
    req.user.tokens = req.user.tokens.filter((token) => {
      return token.token !== req.token;
    });

    // // for removing whole array
    // req.user.tokens = [];

    res.clearCookie("user");
    await req.user.save();
    res.redirect("/signin");
  } catch (error) {
    res.status(500).send(error);
  }
};
