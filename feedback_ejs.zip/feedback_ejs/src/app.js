const express = require("express");
const path = require("path");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const ejs = require("ejs");
const app = express();

const port = process.env.PORT || 4000;

// .ENV
require("dotenv").config();

// IMPORTED MONGODB AND MQTT CONNECTION FILES
require("./db/mongodb.js");

// IMPORTED MANIFEST JSON

// IMPORTED DATA FORM DB DIRECTORIES
const UserDetails = require("../src/models/userDetails");

// IMPORTED DATA FORM MQTT
const MqttData = require("../src/mqtt/mqtt");

// IMPORTED COOKIES FORM AUTH
const auth = require("../src/middleware/auth");

// DIR PATHS FOR DIR
const static_path = path.join(__dirname, "../public");
const views = path.join(__dirname, "../views");

// DEFINE PATH FOR STATIC CSS AND JS
app.use(express.static(static_path));

// COOKIE PARSER
app.use(cookieParser());

// FOR MESSAGE FLASHING

//JWT TOKEN
// const createToken = async() => {
//     const token = await jwt.sign({_id:'id_token'}, 'secret', {expiresIn: '5 minutes'});
//     console.log(token);

//     const userver = await jwt.verify(token, 'secret');
//     console.log(userver);
// };

// createToken();

// FOR PARSING THE JSON DATA
app.use(express.json());

// EXPRESS FOR URLENCODING
app.use(express.urlencoded({ extended: false }));

// SET VIEWING ENGINE
app.set("view-engine", "ejs");

// SET VIEWING PATH
app.set("views", views);

// DEFINING THE PATH FOR ROUTER FOR EXPRESS
const routers = require("./routes/router");
const { finished } = require("stream");

// USING THE ROUTER FILE
app.use("/", routers);

app.listen(port, () => console.log(`Server Started on Port ${port}`));
