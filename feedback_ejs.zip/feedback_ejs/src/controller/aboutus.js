// ABOUTUS
exports.aboutus = (req,res) => {
    res.render('aboutus.ejs', {title: 'aboutus'});
}
