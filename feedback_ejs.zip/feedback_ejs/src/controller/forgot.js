const bcrypt = require("bcryptjs");
const userDetails = require("../models/userDetails");
const jwt = require("jsonwebtoken");

// FORGOT
exports.forgot = (req, res) => {
  res.render("forgot.ejs", { title: "forgot" });
};

// USEING FORGOT PASSWORD
exports.authforgot = async (req, res) => {
  try {
    const email = req.body.email;
    const useremail = await userDetails.findOne({ email: email });
    const password = req.body.password;
    const repassword = req.body.repassword;

    if (email === useremail.email && password === repassword) {


      const token = await useremail.genrateAuthToken();
      res.cookie("user", token, {
        expires: new Date(Date.now() + 300000),
        httpOnly: true,
        // secure: true
      });

      const newpassword = await bcrypt.hash(password, 10);
      const newrepassword = await bcrypt.hash(password, 10);

      const userRegisterd  = await userDetails.updateOne({ useremail },{
        $set: {
          password: newpassword ,
          confirmpassword: newrepassword ,
        }, 
      });

      res.status(201).redirect("/signin");
    } else res.send("INVALID CREDENTIALS");
  } catch (error) {
    res.status(400).send(error);
  }
};
