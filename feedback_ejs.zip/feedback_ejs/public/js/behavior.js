const barChart = document.getElementById("bar").getContext("2d");
const bar = new Chart(barChart, {
  type: "bar",
  data: {
    labels: ["Very Goog", "Good", "Average", "Bad", "Very Bad"],
    datasets: [
      {
        label: "Feedback",
        data: [4, 5, 6, 5, 4],
        backgroundColor: [
          "rgba(75, 192, 192, 0.2)",
          "rgba(75, 192, 192, 0.2)",
          "rgba(255, 159, 64, 0.2)",
          "rgba(255, 99, 132, 0.2)",
          "rgba(255, 99, 132, 0.2)",
        ],
        borderColor: [
          "rgba(75, 192, 192, 1)",
          "rgba(75, 192, 192, 1)",
          "rgba(255, 159, 64, 1)",
          "rgba(255, 99, 132, 1)",
          "rgba(255, 99, 132, 1)",
        ],
        borderWidth: 1,
      },
    ],
  },
  options: {
    scales: {
      y: {
        ticks: {
          callback: function (val, index) {
            return index;
          },
        },
      },
    },
  },
});

const lineChart = document.getElementById("line").getContext("2d");
const line = new Chart(lineChart, {
  type: "line",
  data: {
    labels: ["Very Clear", "Clear", "Ok", "Dirty", "Very Dirty"],
    datasets: [
      {
        label: "Feedback",
        data: [10, 8, 5, 6, 2],
        backgroundColor: ["rgba(75, 192, 192, 0.2)"],
        borderColor: ["rgba(75, 192, 192, 1)"],
        borderWidth: 4,
      },
    ],
  },
  options: {
    scales: {
      y: {
        ticks: {
          callback: function (val, index) {
            return index;
          },
        },
      },
    },
  },
});

