const express = require("express");
const Router = express.Router();
const viewlayout = require("../controller/viewlayout");
const aboutuscontroller = require("../controller/aboutus");
const signincontroller = require("../controller/signin");
const signupcontroller = require("../controller/signup");
const forgotcontroller = require("../controller/forgot");
const profilecontroller = require("../controller/profile");
const signoutcontroller = require("../controller/signout");
const feedbackcontroller = require("../controller/feedback");
const datacontroller = require("../controller/data");
const analyticscontroller = require("../controller/analytics");
const behaviorcontroller = require("../controller/behavior");
const tablecontroller = require("../controller/table");
const buynowcontroller = require("../controller/buynow");
const aboutvpcontroller = require("../controller/aboutvp");
const auth = require("../middleware/auth");

// ALL ROUTES
Router.get("/", viewlayout.index);
Router.get("/aboutus", aboutuscontroller.aboutus);
Router.get("/signin", signincontroller.signin);
Router.post("/signin", signincontroller.authsignin);
Router.get("/signup", signupcontroller.signup);
Router.post("/signup", signupcontroller.authsignup);
Router.get("/forgot", forgotcontroller.forgot);
Router.post("/forgot", forgotcontroller.authforgot);
Router.get("/profile", auth, profilecontroller.profile);
Router.get("/signout", auth, signoutcontroller.signout);
Router.get("/feedback", auth, feedbackcontroller.feedback);
Router.get("/data", auth, datacontroller.data);
Router.get("/analytics", auth, analyticscontroller.analytics);
Router.get("/behavior", auth, behaviorcontroller.behavior);
Router.get("/table", auth, tablecontroller.table);
Router.get("/buynow", auth, buynowcontroller.buynow);
Router.get("/aboutvp", auth, aboutvpcontroller.aboutvp);

// EXPORT ROUTER
module.exports = Router;
