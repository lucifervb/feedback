self.addEventListener('install', evt => {
    console.log('Service Worker Installed')
})

self.addEventListener('activate', evt => {
    console.log('Service Worker Activated')
})

self.addEventListener('fetch', evt => {
    // console.log('Service Worker Fetch', evt)
})