const polarAreaChart = document.getElementById("polarArea").getContext("2d");
const polarArea = new Chart(polarAreaChart, {
  type: "polarArea",
  data: {
    labels: ["Very Goog", "Good", "Average", "Bad", "Very Bad"],
    datasets: [
      {
        data: [4, 5, 8, 5, 4],
        backgroundColor: [
          "rgba(75, 192, 192, 0.2)",
          "rgba(75, 192, 192, 0.2)",
          "rgba(255, 159, 64, 0.2)",
          "rgba(255, 99, 132, 0.2)",
          "rgba(255, 99, 132, 0.2)",
        ],
        borderColor: [
          "rgba(75, 192, 192, 1)",
          "rgba(75, 192, 192, 1)",
          "rgba(255, 159, 64, 1)",
          "rgba(255, 99, 132, 1)",
          "rgba(255, 99, 132, 1)",
        ],
        borderWidth: 1,
      },
    ],
  },
  options: {
    scales: {
      y: {
        ticks: {
          callback: function (val, index) {
            return index;
          },
        },
      },
    },
  },
});
